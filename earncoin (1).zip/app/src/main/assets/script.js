/**
 * EARNCOIN CORE ENGINE
 * Pure Vanilla ES6 JavaScript Implementation
 * Handles local storage synchronization, animation, interactive simulations, and form validations.
 */

document.addEventListener("DOMContentLoaded", () => {
    
    // 1. STATE CONFIGURATION
    const DEFAULT_STATE = {
        coins: 0,
        adsWatchedToday: 0,
        lastDailyCheckIn: null, // ISO string
        username: "CyberEarner_99",
        bkashNumber: "01712345678",
        theme: "cyberpunk",
        limits: {
            reward: 0, // starts at 0 watched
            interstitial: 0, // 0 watched
            open: 0, // 0 watched
            native: 0 // 0 watched
        },
        transactions: []
    };

    let state = loadState();

    // 2. AD CHANNELS INFORMATION
    const AD_CHANNELS = {
        reward: { label: "Reward Video Ad", payout: 50, limitMax: 50 },
        interstitial: { label: "Interstitial Ad", payout: 20, limitMax: 20 },
        open: { label: "App Open Ad", payout: 15, limitMax: 15 },
        native: { label: "Native Graphic Ad", payout: 15, limitMax: 15 }
    };

    // 3. CACHED HTML NODES
    const elements = {
        navBalance: document.getElementById("nav-balance"),
        heroBalance: document.getElementById("hero-balance"),
        bdtBalance: document.getElementById("bdt-balance"),
        walletBalanceVal: document.getElementById("wallet-balance-val"),
        walletBdtVal: document.getElementById("wallet-bdt-val"),
        walletTonVal: document.getElementById("wallet-ton-val"),
        
        // Navigation / Sidemenu
        sidebar: document.getElementById("sidebar"),
        sidebarToggle: document.getElementById("sidebar-toggle"),
        sections: document.querySelectorAll(".content-section"),
        navLinks: document.querySelectorAll(".nav-link"),
        sidebarLinks: document.querySelectorAll(".sidebar-link"),
        
        // Profiles & Dropdowns
        profileTrigger: document.getElementById("profile-trigger"),
        profileDropdown: document.getElementById("profile-dropdown"),
        notifBtn: document.getElementById("notif-btn"),
        notifDropdown: document.getElementById("notif-dropdown"),
        
        // Dashboard / Actions
        btnDailyCheckin: document.getElementById("btn-daily-checkin"),
        floatingCoins: document.getElementById("floating-coins"),
        
        // Watch Ads Nodes
        terminalAdsGrid: document.getElementById("terminal-ads-grid"),
        terminalStats: document.getElementById("terminal-stats"),
        bannerProgressLbl: document.getElementById("banner-progress-lbl"),
        bannerProgressFill: document.getElementById("banner-progress-fill"),
        filterTabs: document.querySelectorAll(".filter-tab"),
        
        // Limits & Milestone Widgets
        rewardLimitLbl: document.getElementById("reward-limit-lbl"),
        interstitialLimitLbl: document.getElementById("interstitial-limit-lbl"),
        openLimitLbl: document.getElementById("open-limit-lbl"),
        nativeLimitLbl: document.getElementById("native-limit-lbl"),
        
        rewardLimitProgress: document.getElementById("reward-limit-progress"),
        interstitialLimitProgress: document.getElementById("interstitial-limit-progress"),
        openLimitProgress: document.getElementById("open-limit-progress"),
        nativeLimitProgress: document.getElementById("native-limit-progress"),
        
        bonusCountText: document.getElementById("bonus-count-text"),
        bonusPercentText: document.getElementById("bonus-percent-text"),
        bonusProgressFill: document.getElementById("bonus-progress-fill"),
        claimBonusBtn: document.getElementById("claim-bonus-btn"),
        
        // Leaderboard
        leaderboardRows: document.getElementById("leaderboard-rows"),
        
        // Wallet / Withdraw
        withdrawForm: document.getElementById("withdraw-form"),
        methodBkash: document.getElementById("method-bkash"),
        methodTon: document.getElementById("method-ton"),
        walletInputLbl: document.getElementById("wallet-input-lbl"),
        walletRecipient: document.getElementById("wallet-recipient"),
        walletHelperText: document.getElementById("wallet-helper-text"),
        withdrawAmount: document.getElementById("withdraw-amount"),
        btnMaxWithdraw: document.getElementById("btn-max-withdraw"),
        liveConversionLbl: document.getElementById("live-conversion-lbl"),
        btnSubmitWithdrawal: document.getElementById("btn-submit-withdrawal"),
        
        // Transactions
        transactionRows: document.getElementById("transaction-rows"),
        
        // Settings
        settingsForm: document.getElementById("settings-form"),
        settingsUsername: document.getElementById("settings-username"),
        settingsEmail: document.getElementById("settings-email"),
        settingsCurrency: document.getElementById("settings-currency"),
        settingsBkash: document.getElementById("settings-bkash"),
        themeDefault: document.getElementById("theme-default"),
        themeClassic: document.getElementById("theme-classic"),
        themeGold: document.getElementById("theme-gold"),
        btnSaveSettings: document.getElementById("btn-save-settings"),
        
        // Modals
        modalReward: document.getElementById("modal-reward"),
        modalRewardAmount: document.getElementById("modal-reward-amount"),
        modalRewardSubtext: document.getElementById("modal-reward-subtext"),
        btnModalClose: document.getElementById("btn-modal-close"),
        
        modalAdSandbox: document.getElementById("modal-ad-sandbox"),
        sandboxCountdown: document.getElementById("sandbox-countdown"),
        sandboxTitle: document.getElementById("sandbox-title"),
        sandboxProgressFill: document.getElementById("sandbox-progress-fill"),
        btnSkipAd: document.getElementById("btn-skip-ad"),
        
        toastContainer: document.getElementById("toast-container")
    };

    // 4. MAIN APP INITIALIZATION
    function init() {
        applyTheme(state.theme);
        updateBalanceUI(state.coins, false);
        renderDailyLimits();
        renderBonusMilestone();
        renderLeaderboard();
        renderTransactions();
        setupEventListeners();
        renderTerminalAds("all");
        
        // Set values in forms
        elements.settingsUsername.value = state.username;
        elements.settingsBkash.value = state.bkashNumber;
        
        // Generate automatic floating coins in chest
        generateFloatingCoins();
        
        // Set dynamic date in profile
        document.querySelector(".profile-meta h4").innerText = state.username;
        
        // Check if daily check-in was already done today
        checkDailyCheckinStatus();
    }

    // Load state from localStorage
    function loadState() {
        const saved = localStorage.getItem("earncoin_state_v3");
        if (saved) {
            try {
                return JSON.parse(saved);
            } catch (e) {
                console.error("Failed parsing storage state, resetting to default.", e);
            }
        }
        return { ...DEFAULT_STATE };
    }

    // Save state to localStorage
    function saveState() {
        localStorage.setItem("earncoin_state_v3", JSON.stringify(state));
    }

    // 5. EVENT LISTENERS SETUP
    function setupEventListeners() {
        
        // Toggle Sidebar Menu
        elements.sidebarToggle.addEventListener("click", () => {
            elements.sidebar.classList.toggle("active");
        });

        // Close sidebar if clicking main area on mobile
        document.addEventListener("click", (e) => {
            if (window.innerWidth <= 768) {
                if (!elements.sidebar.contains(e.target) && !elements.sidebarToggle.contains(e.target)) {
                    elements.sidebar.classList.remove("active");
                }
            }
        });

        // Dropdowns toggling
        elements.profileTrigger.addEventListener("click", (e) => {
            e.stopPropagation();
            elements.notifDropdown.classList.remove("active");
            elements.profileDropdown.classList.toggle("active");
        });

        elements.notifBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            elements.profileDropdown.classList.remove("active");
            elements.notifDropdown.classList.toggle("active");
        });

        document.addEventListener("click", () => {
            elements.profileDropdown.classList.remove("active");
            elements.notifDropdown.classList.remove("active");
        });

        // Section Routing (Sidebar & Navbar)
        const allNavigators = [...elements.navLinks, ...elements.sidebarLinks, ...document.querySelectorAll(".profile-menu .menu-item")];
        allNavigators.forEach(btn => {
            btn.addEventListener("click", (e) => {
                e.preventDefault();
                const targetId = btn.getAttribute("data-target");
                if (targetId) {
                    navigateToSection(targetId);
                }
            });
        });

        // Watch Ad button trigger in list/cards
        document.addEventListener("click", (e) => {
            const watchBtn = e.target.closest(".watch-ad-btn");
            if (watchBtn) {
                const adId = watchBtn.getAttribute("data-id");
                const coinsReward = parseInt(watchBtn.getAttribute("data-coins"));
                const label = watchBtn.getAttribute("data-label");
                
                // Check daily limits
                if (state.limits[adId] <= 0) {
                    showToast(`Error: Daily limit for ${label} reached. Refreshes in 24h.`, "error");
                    return;
                }
                
                triggerAdStreamSimulation(adId, coinsReward, label);
                return;
            }

            const bannerAd = e.target.closest(".card-inline-banner");
            if (bannerAd) {
                // Banner ad click displays a fast 3-second reward simulation
                elements.modalAdSandbox.classList.add("active");
                elements.btnSkipAd.disabled = true;
                
                let secondsLeft = 3;
                elements.sandboxCountdown.innerText = `0${secondsLeft}s`;
                elements.sandboxTitle.innerText = "STREAMING PARTNER SPONSORED BANNER";
                elements.sandboxProgressFill.style.width = "0%";

                setTimeout(() => {
                    elements.sandboxProgressFill.style.transition = "width 3s linear";
                    elements.sandboxProgressFill.style.width = "100%";
                }, 100);

                const countdownTimer = setInterval(() => {
                    secondsLeft--;
                    elements.sandboxCountdown.innerText = `0${secondsLeft}s`;
                    
                    if (secondsLeft <= 0) {
                        clearInterval(countdownTimer);
                        elements.btnSkipAd.disabled = false;
                        elements.btnSkipAd.innerHTML = `<span class="btn-glow"></span><i class="fa-solid fa-circle-check"></i> EXTRACT REWARD`;
                    }
                }, 1000);

                const rewardButtonAction = () => {
                    clearInterval(countdownTimer);
                    elements.modalAdSandbox.classList.remove("active");
                    
                    state.coins += 5;
                    
                    const adTx = {
                        id: "TX-" + Math.floor(10000 + Math.random() * 90000),
                        date: formatCurrentDateTime(),
                        type: "Partner Banner Reward",
                        desc: "Sponsored Partner Banner",
                        status: "Success",
                        coins: 5
                    };
                    state.transactions.unshift(adTx);
                    
                    saveState();
                    updateBalanceUI(state.coins);
                    renderTransactions();
                    
                    showRewardPopup(5, "Banner view mining success!");
                    showToast("Mined +5 Coins from Sponsored Banner.", "success");
                    
                    elements.btnSkipAd.removeEventListener("click", rewardButtonAction);
                };

                elements.btnSkipAd.addEventListener("click", rewardButtonAction);
            }
        });

        // Claim check-in trigger
        elements.btnDailyCheckin.addEventListener("click", () => {
            claimDailyCheckin();
        });

        // Modals buttons
        elements.btnModalClose.addEventListener("click", () => {
            elements.modalReward.classList.remove("active");
        });

        // Withdraw Methods switching
        elements.methodBkash.addEventListener("click", () => {
            elements.methodBkash.classList.add("active");
            elements.methodTon.classList.remove("active");
            elements.walletInputLbl.innerText = "bKash Account Phone Number";
            elements.walletRecipient.placeholder = "017XXXXXXXX";
            elements.walletHelperText.innerText = "Please provide valid 11-digit Bangladeshi mobile number.";
            updateWithdrawCalculations();
        });

        elements.methodTon.addEventListener("click", () => {
            elements.methodTon.classList.add("active");
            elements.methodBkash.classList.remove("active");
            elements.walletInputLbl.innerText = "Telegram Toncoin Wallet Address";
            elements.walletRecipient.placeholder = "UQBy...76gh";
            elements.walletHelperText.innerText = "Provide TON address (must support smart contracts).";
            updateWithdrawCalculations();
        });

        // Max Withdraw trigger
        elements.btnMaxWithdraw.addEventListener("click", () => {
            elements.withdrawAmount.value = state.coins;
            updateWithdrawCalculations();
        });

        elements.withdrawAmount.addEventListener("input", updateWithdrawCalculations);

        // Submit Withdrawal
        elements.btnSubmitWithdrawal.addEventListener("click", () => {
            processWithdrawal();
        });

        // Copy Referral Link
        document.getElementById("btn-copy-ref").addEventListener("click", () => {
            const link = document.getElementById("ref-link");
            link.select();
            document.execCommand("copy");
            showToast("Referral link copied to clipboard successfully!", "success");
        });

        // Save Settings trigger
        elements.btnSaveSettings.addEventListener("click", () => {
            saveUserSettings();
        });

        // Watch Ads Filters switching
        elements.filterTabs.forEach(tab => {
            tab.addEventListener("click", () => {
                elements.filterTabs.forEach(t => t.classList.remove("active"));
                tab.classList.add("active");
                const filter = tab.getAttribute("data-filter");
                renderTerminalAds(filter);
            });
        });

        // Theme customized buttons
        elements.themeDefault.addEventListener("click", () => {
            applyTheme("cyberpunk");
            elements.themeDefault.classList.add("active");
            elements.themeClassic.classList.remove("active");
            elements.themeGold.classList.remove("active");
        });

        elements.themeClassic.addEventListener("click", () => {
            applyTheme("classic");
            elements.themeClassic.classList.add("active");
            elements.themeDefault.classList.remove("active");
            elements.themeGold.classList.remove("active");
        });

        elements.themeGold.addEventListener("click", () => {
            applyTheme("gold");
            elements.themeGold.classList.add("active");
            elements.themeClassic.classList.remove("active");
            elements.themeDefault.classList.remove("active");
        });

        // Support trigger simulate
        document.getElementById("support-link").addEventListener("click", (e) => {
            e.preventDefault();
            showToast("Encrypted connection opened. Direct Support node ready.", "success");
        });

        // Claim bonus trigger
        elements.claimBonusBtn.addEventListener("click", () => {
            claimMilestoneBonus();
        });

        // Logout simulated
        document.querySelectorAll(".logout-btn").forEach(btn => {
            btn.addEventListener("click", (e) => {
                e.preventDefault();
                showToast("System shutdown sequence initialized. Goodbye Miner!", "error");
                setTimeout(() => {
                    localStorage.removeItem("earncoin_state_new");
                    state = { ...DEFAULT_STATE };
                    saveState();
                    location.reload();
                }, 1500);
            });
        });
    }

    // 6. VIEW NAVIGATION ROUTER
    function navigateToSection(targetId) {
        // Hide all sections
        elements.sections.forEach(sec => sec.classList.remove("active"));
        
        // Show correct section
        const targetSec = document.getElementById(`sec-${targetId}`);
        if (targetSec) {
            targetSec.classList.add("active");
        }

        // Handle Active states of links
        elements.navLinks.forEach(link => {
            if (link.getAttribute("data-target") === targetId) {
                link.classList.add("active");
            } else {
                link.classList.remove("active");
            }
        });

        elements.sidebarLinks.forEach(link => {
            if (link.getAttribute("data-target") === targetId) {
                link.classList.add("active");
            } else {
                link.classList.remove("active");
            }
        });

        // Scroll main viewport to top
        elements.contentViewport.scrollTop = 0;

        // If mobile, automatically close sidebar after choosing option
        if (window.innerWidth <= 768) {
            elements.sidebar.classList.remove("active");
        }
    }

    // 7. COUNTER INCREMENT ANIMATIONS
    function updateBalanceUI(targetVal, animate = true) {
        if (!animate) {
            elements.navBalance.innerText = formatNumber(targetVal);
            elements.heroBalance.innerText = formatNumber(targetVal);
            elements.walletBalanceVal.innerText = formatNumber(targetVal);
            
            // Calculate BDT equivalent (100,000 Coins = $30 USD gross, 1 USD = 120 BDT, so 100,000 Coins = 3,600 BDT)
            const bdtVal = (targetVal * 0.036).toFixed(2);
            elements.bdtBalance.innerText = bdtVal;
            elements.walletBdtVal.innerText = bdtVal;
            
            // TON equivalent (100,000 Coins = $30 USD gross, 1 TON = 6 USD, so 100,000 Coins = 5 TON)
            const tonVal = (targetVal * 0.00005).toFixed(4);
            elements.walletTonVal.innerText = tonVal;
            return;
        }

        const animateCounter = (el, start, end, duration, formatFloat = false) => {
            let startTimestamp = null;
            const step = (timestamp) => {
                if (!startTimestamp) startTimestamp = timestamp;
                const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                const current = progress * (end - start) + start;
                
                el.innerText = formatFloat ? current.toFixed(2) : formatNumber(Math.floor(current));
                
                if (progress < 1) {
                    window.requestAnimationFrame(step);
                } else {
                    el.innerText = formatFloat ? end.toFixed(2) : formatNumber(end);
                }
            };
            window.requestAnimationFrame(step);
        };

        const triggerEarnEffects = (diff) => {
            // 1. Add pulse-glow class to main balance value
            const balanceContainer = elements.heroBalance.parentElement;
            if (balanceContainer) {
                balanceContainer.classList.add("earning-pulse");
                // Remove the class after animation completes (0.5s) to allow re-triggering
                setTimeout(() => {
                    balanceContainer.classList.remove("earning-pulse");
                }, 500);
            }

            // 2. Spawn a floating green bubble text showing "+X"
            const formattedDiff = formatNumber(diff);
            const floatText = document.createElement("div");
            floatText.className = "earn-float-text";
            floatText.innerText = `+${formattedDiff}`;
            
            if (balanceContainer) {
                balanceContainer.style.position = "relative";
                
                let wrapper = balanceContainer.querySelector(".float-indicator-container");
                if (!wrapper) {
                    wrapper = document.createElement("div");
                    wrapper.className = "float-indicator-container";
                    balanceContainer.appendChild(wrapper);
                }
                wrapper.appendChild(floatText);
                
                // Remove after animation finishes (1.2s)
                setTimeout(() => {
                    floatText.remove();
                }, 1200);
            }

            // 3. Create interactive sparkling particle burst!
            if (balanceContainer) {
                // Spawn 15 colorful golden particles from the center of the balance
                for (let i = 0; i < 15; i++) {
                    const particle = document.createElement("div");
                    particle.className = "balance-sparkle";
                    
                    // Random travel angles and distances
                    const angle = Math.random() * Math.PI * 2;
                    const distance = Math.random() * 55 + 20;
                    const tx = Math.cos(angle) * distance;
                    const ty = Math.sin(angle) * distance;
                    
                    particle.style.setProperty("--tx", `${tx}px`);
                    particle.style.setProperty("--ty", `${ty}px`);
                    
                    // Random size variations
                    const size = Math.random() * 5 + 4;
                    particle.style.width = `${size}px`;
                    particle.style.height = `${size}px`;
                    
                    // Position in center
                    particle.style.left = `50%`;
                    particle.style.top = `50%`;
                    
                    balanceContainer.appendChild(particle);
                    
                    // Cleanup particle
                    setTimeout(() => {
                        particle.remove();
                    }, 700);
                }
            }
        };

        const oldVal = parseInt(elements.heroBalance.innerText.replace(/,/g, "")) || 0;
        
        // Trigger extra effects if user earns coins
        if (targetVal > oldVal && oldVal > 0) {
            triggerEarnEffects(targetVal - oldVal);
        }
        
        // Animate coin counts
        animateCounter(elements.navBalance, oldVal, targetVal, 1000);
        animateCounter(elements.heroBalance, oldVal, targetVal, 1000);
        animateCounter(elements.walletBalanceVal, oldVal, targetVal, 1000);

        // Animate BDT conversions (100,000 Coins = 3,600 BDT, so multiplier is 0.036)
        const oldBdt = parseFloat(elements.bdtBalance.innerText) || 0;
        const newBdt = targetVal * 0.036;
        animateCounter(elements.bdtBalance, oldBdt, newBdt, 1000, true);
        animateCounter(elements.walletBdtVal, oldBdt, newBdt, 1000, true);

        // Animate TON coin conversion (100,000 Coins = 5 TON, so multiplier is 0.00005)
        const newTon = targetVal * 0.00005;
        elements.walletTonVal.innerText = newTon.toFixed(4);
    }

    // 8. DECORATIVE CHEST FLOATING COINS
    function generateFloatingCoins() {
        const createCoinParticle = () => {
            const coin = document.createElement("div");
            coin.className = "floating-coin";
            coin.innerHTML = '<i class="fa-solid fa-coins"></i>';
            
            // Random horizontal offsets
            const randomX = Math.random() * 120 + 20;
            coin.style.left = `${randomX}px`;
            
            // Random duration and delay
            const duration = Math.random() * 1.5 + 1.5;
            coin.style.animationDuration = `${duration}s`;
            
            elements.floatingCoins.appendChild(coin);
            
            // Garbage collect particle
            setTimeout(() => {
                coin.remove();
            }, duration * 1000);
        };

        // Create particles periodically
        setInterval(createCoinParticle, 500);
    }

    // 9. DAILY CHECK-IN ACTIONS
    function checkDailyCheckinStatus() {
        if (state.lastDailyCheckIn) {
            const lastCheck = new Date(state.lastDailyCheckIn);
            const now = new Date();
            const hoursDiff = (now - lastCheck) / (1000 * 60 * 60);
            
            if (hoursDiff < 24) {
                // Disable button
                elements.btnDailyCheckin.disabled = true;
                elements.btnDailyCheckin.innerHTML = '<i class="fa-solid fa-clock-rotate-left"></i> CHECKED-IN TODAY';
            }
        }
    }

    // --- GLOBAL ANDROID BRIDGE CALLBACKS ---
    window.onAdCompleted = function(adId, reward, label) {
        if (adId === "daily_checkin") {
            const now = new Date();
            state.lastDailyCheckIn = now.toISOString();
            
            // Add 25 coins
            state.coins += 25;
            
            // Register transaction in ledger
            const checkinTx = {
                id: "TX-" + Math.floor(10000 + Math.random() * 90000),
                date: formatCurrentDateTime(),
                type: "Daily Node Check-in",
                desc: "Standard Network Reward",
                status: "Success",
                coins: 25
            };
            state.transactions.unshift(checkinTx);
            
            // Save
            saveState();
            
            // Update View UI
            updateBalanceUI(state.coins);
            renderTransactions();
            checkDailyCheckinStatus();
            
            // Congrats reward modal popup
            showRewardPopup(25, "Daily Check-In claim complete!");
            showToast("Daily bonus of +25 Coins credited to your node.", "success");
        } else {
            // Deduct daily limit
            if (state.limits[adId] > 0) {
                state.limits[adId]--;
            }
            state.adsWatchedToday++;
            
            // Award coins
            state.coins += reward;
            
            // Append transaction log
            const adTx = {
                id: "TX-" + Math.floor(10000 + Math.random() * 90000),
                date: formatCurrentDateTime(),
                type: "Ad Stream Reward",
                desc: `${label} Stream Session`,
                status: "Success",
                coins: reward
            };
            state.transactions.unshift(adTx);
            
            // Save state
            saveState();
            
            // Redraw everything
            updateBalanceUI(state.coins);
            renderDailyLimits();
            renderBonusMilestone();
            renderTransactions();
            const activeFilter = document.querySelector(".filter-tab.active");
            const filterName = activeFilter ? activeFilter.getAttribute("data-filter") : "all";
            renderTerminalAds(filterName || "all");
            
            // Congrats Dialog popup
            showRewardPopup(reward, `Mining success! Earned from ${label}.`);
            showToast(`Mined +${reward} Coins securely.`, "success");
        }
    };

    window.onAdFailedToLoad = function(adId, reward, label) {
        // Fall back to local html simulation screen
        if (adId === "daily_checkin") {
            runLocalCheckinSimulation();
        } else {
            runLocalAdSimulation(adId, reward, label);
        }
    };

    function claimDailyCheckin() {
        if (elements.btnDailyCheckin.disabled) return;
        
        if (typeof AndroidBridge !== "undefined") {
            try {
                AndroidBridge.showAd("daily_checkin", 25, "Daily Check-In Ad");
                return;
            } catch (e) {
                console.error("AndroidBridge Error:", e);
            }
        }
        runLocalCheckinSimulation();
    }

    function runLocalCheckinSimulation() {
        // Open simulation screen modal
        elements.modalAdSandbox.classList.add("active");
        elements.btnSkipAd.disabled = true;
        
        let secondsLeft = 5;
        elements.sandboxCountdown.innerText = `0${secondsLeft}s`;
        elements.sandboxTitle.innerText = "STREAMING DAILY CHECK-IN REWARD AD";
        elements.sandboxProgressFill.style.width = "0%";

        // Reset progress bar animation
        setTimeout(() => {
            elements.sandboxProgressFill.style.transition = "width 5s linear";
            elements.sandboxProgressFill.style.width = "100%";
        }, 100);

        const countdownTimer = setInterval(() => {
            secondsLeft--;
            elements.sandboxCountdown.innerText = `0${secondsLeft}s`;
            
            if (secondsLeft <= 0) {
                clearInterval(countdownTimer);
                elements.btnSkipAd.disabled = false;
                elements.btnSkipAd.innerHTML = `<span class="btn-glow"></span><i class="fa-solid fa-circle-check"></i> EXTRACT REWARD`;
            }
        }, 1000);

        const rewardButtonAction = () => {
            clearInterval(countdownTimer);
            elements.modalAdSandbox.classList.remove("active");
            
            window.onAdCompleted("daily_checkin", 25, "Daily Check-In Ad");
            elements.btnSkipAd.removeEventListener("click", rewardButtonAction);
        };

        elements.btnSkipAd.addEventListener("click", rewardButtonAction);
    }

    // 10. AD STREAM INTERACTIVE SIMULATION
    function triggerAdStreamSimulation(adId, reward, label) {
        if (typeof AndroidBridge !== "undefined") {
            try {
                AndroidBridge.showAd(adId, reward, label);
                return;
            } catch (e) {
                console.error("AndroidBridge Error:", e);
            }
        }
        runLocalAdSimulation(adId, reward, label);
    }

    function runLocalAdSimulation(adId, reward, label) {
        // Open simulation screen modal
        elements.modalAdSandbox.classList.add("active");
        elements.btnSkipAd.disabled = true;
        elements.btnSkipAd.innerHTML = `<span class="btn-glow"></span><i class="fa-solid fa-hourglass-half"></i> WATCHING AD...`;
        
        // Select a beautiful randomized futuristic ad concept
        const mockAdsList = [
            {
                title: "CYBER CORE MINER 3000",
                tag: "HARDWARE DEPLOYMENT",
                desc: "Unleash extreme mining rates with overclocked quantum processing units.",
                icon: "fa-solid fa-microchip",
                color: "var(--neon-blue)"
            },
            {
                title: "SYNAPSE AI COGNITIVE NODE",
                tag: "DEEP NEURAL MODEL",
                desc: "Powering autonomous AI agents with synaptic network architectures.",
                icon: "fa-solid fa-brain",
                color: "var(--neon-purple)"
            },
            {
                title: "APEX YIELD LEDGER v5.1",
                tag: "DECENTRALIZED FINANCE",
                desc: "Decentralized automated staking pool returning premium blockchain interest.",
                icon: "fa-solid fa-cubes-stacked",
                color: "var(--neon-gold)"
            },
            {
                title: "NEXUS METAVERSE METROPOLIS",
                tag: "VIRTUAL SYSTEM CHRONICLES",
                desc: "Own digital apartments and construct properties in the heart of Neon City.",
                icon: "fa-solid fa-vr-cardboard",
                color: "#ff007f"
            }
        ];
        
        const selectedAd = mockAdsList[Math.floor(Math.random() * mockAdsList.length)];
        const simGraphic = document.querySelector(".simulation-graphic");
        const originalGraphicHTML = simGraphic.innerHTML;
        
        // Render beautiful responsive ad visuals
        simGraphic.innerHTML = `
            <div class="animate-float" style="text-align: center; display: flex; flex-direction: column; align-items: center; gap: 8px;">
                <div style="font-size:10px; text-transform:uppercase; color:${selectedAd.color}; font-weight:700; letter-spacing:2px; margin-bottom:4px; border: 1px solid ${selectedAd.color}44; padding: 2px 10px; border-radius: 12px; background: ${selectedAd.color}11;">
                    ${selectedAd.tag}
                </div>
                <i class="${selectedAd.icon}" style="font-size:42px; color:${selectedAd.color}; filter: drop-shadow(0 0 12px ${selectedAd.color}); margin: 10px 0;"></i>
                <div class="simulation-title" style="color:var(--text-primary); font-size:18px; font-weight:800; letter-spacing: 0.5px;">
                    ${selectedAd.title}
                </div>
                <div class="simulation-sub" style="font-size: 11px; max-width:85%; line-height:1.4; color: var(--text-secondary); margin-top:4px;">
                    ${selectedAd.desc}
                </div>
            </div>
        `;

        let secondsLeft = 5;
        elements.sandboxCountdown.innerText = `0${secondsLeft}s`;
        elements.sandboxProgressFill.style.width = "0%";

        // Reset progress bar animation
        setTimeout(() => {
            elements.sandboxProgressFill.style.transition = "width 5s linear";
            elements.sandboxProgressFill.style.width = "100%";
        }, 100);

        const countdownTimer = setInterval(() => {
            secondsLeft--;
            elements.sandboxCountdown.innerText = `0${secondsLeft}s`;
            
            if (secondsLeft <= 0) {
                clearInterval(countdownTimer);
                elements.btnSkipAd.disabled = false;
                elements.btnSkipAd.innerHTML = `<span class="btn-glow"></span><i class="fa-solid fa-circle-check"></i> EXTRACT REWARD`;
            }
        }, 1000);

        // Set action on reward extraction/skip
        const rewardButtonAction = () => {
            clearInterval(countdownTimer);
            elements.modalAdSandbox.classList.remove("active");
            
            // Restore original HTML graphic for the next view
            simGraphic.innerHTML = originalGraphicHTML;
            
            window.onAdCompleted(adId, reward, label);
            elements.btnSkipAd.removeEventListener("click", rewardButtonAction);
        };

        elements.btnSkipAd.addEventListener("click", rewardButtonAction);
    }

    // Show popup
    function showRewardPopup(amount, subtitle) {
        elements.modalRewardAmount.innerText = `+${amount}`;
        elements.modalRewardSubtext.innerText = subtitle;
        elements.modalReward.classList.add("active");
    }

    // 11. LIMIT WIDGET RENDERERS
    function renderDailyLimits() {
        const keys = ["reward", "interstitial", "open", "native"];
        keys.forEach(k => {
            const limitMax = AD_CHANNELS[k].limitMax;
            const current = state.limits[k];
            
            elements[`${k}LimitLbl`].innerText = `${current} / ${limitMax}`;
            const percent = (current / limitMax) * 100;
            elements[`${k}LimitProgress`].style.width = `${percent}%`;
        });
    }

    function renderBonusMilestone() {
        const completed = state.adsWatchedToday;
        elements.terminalStats.innerText = `${completed}/10 Completed today`;
        
        let displayCompleted = completed;
        let percent = (completed / 10) * 100;
        
        if (completed >= 10) {
            percent = 100;
            displayCompleted = 10;
        }

        elements.bonusCountText.innerText = `${displayCompleted} / 10 Watched`;
        elements.bonusPercentText.innerText = `${Math.floor(percent)}%`;
        elements.bonusProgressFill.style.width = `${percent}%`;
        
        elements.bannerProgressLbl.innerText = `${displayCompleted}/10 Completed`;
        elements.bannerProgressFill.style.width = `${percent}%`;

        // Claim super bonus state
        if (completed >= 10) {
            elements.claimBonusBtn.disabled = false;
            elements.claimBonusBtn.innerHTML = '<span class="btn-glow"></span><i class="fa-solid fa-rocket animate-pulse"></i> CLAIM +100 COINS';
            elements.claimBonusBtn.classList.remove("btn-magenta");
            elements.claimBonusBtn.classList.add("btn-gold");
        } else {
            elements.claimBonusBtn.disabled = true;
            elements.claimBonusBtn.innerHTML = '<i class="fa-solid fa-lock"></i> LOCK BONUS';
            elements.claimBonusBtn.classList.remove("btn-gold");
            elements.claimBonusBtn.classList.add("btn-magenta");
        }
    }

    // Claim Super Bonus 100 coins
    function claimMilestoneBonus() {
        if (state.adsWatchedToday < 10) return;
        
        // Reward 100 coins
        state.coins += 100;
        
        // Reset count
        state.adsWatchedToday = 0;
        
        // Append trans
        const bonusTx = {
            id: "TX-" + Math.floor(10000 + Math.random() * 90000),
            date: formatCurrentDateTime(),
            type: "Super Milestone Bonus",
            desc: "10 Sponsored Streams Reward",
            status: "Success",
            coins: 100
        };
        state.transactions.unshift(bonusTx);
        
        saveState();
        
        updateBalanceUI(state.coins);
        renderBonusMilestone();
        renderTransactions();
        
        showRewardPopup(100, "10 Streams milestone reward claim completed.");
        showToast("Super milestone bonus of +100 Coins successfully credited!", "success");
    }

    // 12. DYNAMIC TERMINAL AD CARDS LIST
    function renderTerminalAds(filter) {
        elements.terminalAdsGrid.innerHTML = "";
        
        const cardBlueprints = [
            { id: "reward", label: "Elite Video Stream Node #1A", speed: "1.2 MB/s", coins: 50, desc: "High value gaming and crypto application commercial streams." },
            { id: "reward", label: "Elite Video Stream Node #1B", speed: "1.5 MB/s", coins: 50, desc: "Sponsored tech gadgets and blockchain ledger tutorials." },
            { id: "interstitial", label: "Interstitial Flash Node #2A", speed: "800 KB/s", coins: 20, desc: "Quick fullscreen fintech marketing splash banner breaks." },
            { id: "interstitial", label: "Interstitial Flash Node #2B", speed: "950 KB/s", coins: 20, desc: "Short video ads showcasing direct e-banking services." },
            { id: "open", label: "Launch Splash Graphic Node #3A", speed: "600 KB/s", coins: 15, desc: "Simulate splash openings for new Web3 products." },
            { id: "native", label: "Inline Banner Graphic Node #4A", speed: "400 KB/s", coins: 15, desc: "Compact native feed poster highlighting dynamic investments." }
        ];

        const filtered = filter === "all" ? cardBlueprints : cardBlueprints.filter(c => c.id === filter);
        
        if (filtered.length === 0) {
            elements.terminalAdsGrid.innerHTML = `
                <div class="glass-panel neon-border-blue" style="grid-column: 1/-1; padding: 40px; text-align: center; color: var(--text-secondary);">
                    <i class="fa-solid fa-rectangle-xmark" style="font-size: 40px; margin-bottom: 12px; color: var(--neon-blue);"></i>
                    <h3>No active streams available on this channel</h3>
                    <p>Select another channel above to load more active mining nodes.</p>
                </div>
            `;
            return;
        }

        filtered.forEach(blue => {
            const borderCls = blue.id === "reward" ? "blue" : (blue.id === "interstitial" ? "purple" : "gold");
            const btnCls = blue.id === "reward" ? "btn-blue" : (blue.id === "interstitial" ? "btn-purple" : "btn-gold");
            const isLimitReached = state.limits[blue.id] <= 0;
            
            const card = document.createElement("div");
            card.className = `ad-card glass-panel neon-border-${borderCls}`;
            card.innerHTML = `
                <div class="ad-badge-top" style="background: ${isLimitReached ? 'grey' : ''}">${isLimitReached ? 'USED' : 'ONLINE'}</div>
                <div class="ad-card-icon ${borderCls}-glow"><i class="fa-solid fa-server"></i></div>
                <h4>${blue.label}</h4>
                <p class="ad-desc">${blue.desc}</p>
                <div class="reward-tag" style="display:flex; justify-content: space-between; font-size:12px; width:100%; margin-bottom:14px; padding: 6px 10px;">
                    <span><i class="fa-solid fa-gauge-high"></i> ${blue.speed}</span>
                    <span><i class="fa-solid fa-coins"></i> +${blue.coins} Coins</span>
                </div>
                <button class="watch-ad-btn cyber-btn ${btnCls} btn-full-width" data-id="${blue.id}" data-coins="${blue.coins}" data-label="${blue.label}" ${isLimitReached ? 'disabled' : ''}>
                    <span class="btn-glow"></span>
                    <i class="fa-solid fa-play"></i> ${isLimitReached ? 'LIMIT EXCEEDED' : 'CONNECT NODE'}
                </button>
                <!-- Banner Ad Below Option -->
                <div class="card-inline-banner">
                    <span class="banner-badge">SPONSORED BANNER</span>
                    <span class="banner-click-text">Click to mine +5 Coins</span>
                </div>
            `;
            elements.terminalAdsGrid.appendChild(card);
        });
    }

    // 13. REAL-TIME SIMULATED LEADERBOARD
    function renderLeaderboard() {
        elements.leaderboardRows.innerHTML = "";
        
        // Mock data
        const miners = [
            { rank: 1, name: "CryptoKnight_7", rate: "2.4 MH/s", coins: 54200 },
            { rank: 2, name: "NexusQueen_88", rate: "1.9 MH/s", coins: 38920 },
            { rank: 3, name: "PixelLord_01", rate: "1.5 MH/s", coins: 31450 },
            { rank: 4, name: "QuantumGlitch_5", rate: "1.2 MH/s", coins: 24105 },
            { rank: 5, name: state.username, rate: "1.0 MH/s", coins: state.coins, isUser: true },
            { rank: 6, name: "BlockSlasher_x", rate: "0.8 MH/s", coins: 11050 },
            { rank: 7, name: "EtherGhost_z", rate: "0.6 MH/s", coins: 8945 }
        ];

        // Sort on score
        miners.sort((a, b) => b.coins - a.coins);
        
        // Recalculate Rank
        miners.forEach((m, idx) => {
            m.rank = idx + 1;
        });

        miners.forEach(m => {
            const row = document.createElement("tr");
            if (m.isUser) {
                row.className = "highlight-user";
            }
            
            const payoutBdt = (m.coins / 100).toFixed(2);
            const avatarImg = m.isUser 
                ? "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&w=150&q=80"
                : `https://images.unsplash.com/photo-${1500000000000 + (m.rank * 100000)}?auto=format&fit=crop&w=80&q=80`;

            row.innerHTML = `
                <td>
                    <strong class="${m.rank <= 3 ? 'text-gold' : 'text-secondary'}">#${m.rank}</strong>
                </td>
                <td>
                    <div class="table-avatar-wrapper">
                        <img src="${avatarImg}" alt="Avatar" class="table-avatar">
                        <span class="table-username">${m.name} ${m.isUser ? '<span class="status-live">YOU</span>' : ''}</span>
                    </div>
                </td>
                <td>
                    <span class="text-blue"><i class="fa-solid fa-bolt"></i> ${m.rate}</span>
                </td>
                <td>
                    <strong class="text-gold"><i class="fa-solid fa-coins"></i> ${formatNumber(m.coins)}</strong>
                </td>
                <td>
                    <strong class="text-green">৳ ${payoutBdt} BDT</strong>
                </td>
            `;
            elements.leaderboardRows.appendChild(row);
        });
    }

    // 14. TRANSACTIONS LEDGER RENDERING
    function renderTransactions() {
        elements.transactionRows.innerHTML = "";
        
        if (state.transactions.length === 0) {
            elements.transactionRows.innerHTML = `
                <tr>
                    <td colspan="5" style="text-align: center; padding: 40px; color: var(--text-secondary);">
                        <i class="fa-solid fa-folder-open" style="font-size: 32px; margin-bottom: 8px;"></i>
                        <p>No transactions registered on this node ledger yet.</p>
                    </td>
                </tr>
            `;
            return;
        }

        state.transactions.forEach(tx => {
            const isNegative = tx.coins < 0;
            const coinClass = isNegative ? "text-magenta" : "text-gold";
            const coinSign = isNegative ? "" : "+";
            const icon = isNegative ? '<i class="fa-solid fa-arrow-up-from-bracket"></i>' : '<i class="fa-solid fa-arrow-down-to-bracket"></i>';

            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><span class="text-secondary">${tx.date}</span></td>
                <td><code style="color: var(--neon-blue);">${tx.id}</code></td>
                <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <span class="${coinClass}">${icon}</span>
                        <div>
                            <strong style="display: block; font-size:13px;">${tx.type}</strong>
                            <small class="text-secondary" style="font-size:11px;">${tx.desc}</small>
                        </div>
                    </div>
                </td>
                <td><span class="status-pill success">${tx.status}</span></td>
                <td><strong class="${coinClass}">${coinSign}${formatNumber(tx.coins)} COINS</strong></td>
            `;
            elements.transactionRows.appendChild(tr);
        });
    }

    // 15. WITHDRAW VALIDATIONS & PROCESSING
    function updateWithdrawCalculations() {
        const amt = parseInt(elements.withdrawAmount.value) || 0;
        const method = document.querySelector('input[name="withdraw_method"]:checked').value;
        
        // Calculate gross value, VAT, and net payout based on 100,000 Coins = $30 gross, $3 VAT, $27 net
        const grossUsd = (amt / 100000) * 30;
        const vatUsd = (amt / 100000) * 3;
        const netUsd = grossUsd - vatUsd;
        
        if (method === "bkash") {
            const bdtRate = 120; // 1 USD = 120 BDT
            const bdtPayout = (netUsd * bdtRate).toFixed(2);
            elements.liveConversionLbl.innerHTML = `
                <div style="font-size:12px; line-height: 1.5; color: var(--text-secondary);">
                    Gross: <span style="color:var(--text-primary); font-weight:600;">$${grossUsd.toFixed(2)} USD</span><br>
                    VAT Tax (10%): <span style="color:var(--neon-gold); font-weight:600;">-$${vatUsd.toFixed(2)} USD</span><br>
                    <span style="color:var(--neon-green); font-weight:700; font-size:14px;">Net Payout: $${netUsd.toFixed(2)} USD (~৳${parseFloat(bdtPayout).toLocaleString()} BDT)</span>
                </div>
            `;
        } else {
            const tonRate = 6.0; // 1 TON = 6 USD
            const tonPayout = (netUsd / tonRate).toFixed(4);
            elements.liveConversionLbl.innerHTML = `
                <div style="font-size:12px; line-height: 1.5; color: var(--text-secondary);">
                    Gross: <span style="color:var(--text-primary); font-weight:600;">$${grossUsd.toFixed(2)} USD</span><br>
                    VAT Tax (10%): <span style="color:var(--neon-gold); font-weight:600;">-$${vatUsd.toFixed(2)} USD</span><br>
                    <span style="color:var(--neon-green); font-weight:700; font-size:14px;">Net Payout: $${netUsd.toFixed(2)} USD (~${tonPayout} TON)</span>
                </div>
            `;
        }
    }

    function processWithdrawal() {
        const amt = parseInt(elements.withdrawAmount.value);
        const recipient = elements.walletRecipient.value.trim();
        const method = document.querySelector('input[name="withdraw_method"]:checked').value;
        
        // 1. Validation for minimum amount (100,000 Coins)
        if (isNaN(amt) || amt < 100000) {
            showToast("Error: Minimum withdrawal threshold is 1,00,000 Coins ($30 USD).", "error");
            return;
        }

        // 2. Validation for sufficient balance
        if (amt > state.coins) {
            showToast("Error: Insufficient balance in your secure node ledger.", "error");
            return;
        }

        // 3. Address/Number Validations
        if (!recipient) {
            showToast("Error: Please provide a valid recipient account or address.", "error");
            return;
        }

        if (method === "bkash") {
            const bkashRegex = /^01[3-9]\d{8}$/;
            if (!bkashRegex.test(recipient)) {
                showToast("Error: Please enter a valid 11-digit Bangladeshi bKash number.", "error");
                return;
            }
        } else if (method === "toncoin") {
            if (recipient.length < 24) {
                showToast("Error: Please provide a valid TON wallet address.", "error");
                return;
            }
        }

        // Calculate final details for toast / popup
        const grossUsd = (amt / 100000) * 30;
        const vatUsd = (amt / 100000) * 3;
        const netUsd = grossUsd - vatUsd;

        // 4. Secure deduction and ledger registration
        state.coins -= amt;
        
        const walletLabel = method === "bkash" ? `bKash Wallet (${recipient})` : `TON address (${recipient.substring(0, 6)}...${recipient.slice(-4)})`;
        const claimType = method === "bkash" ? "bKash Transfer" : "TON Blockchain Transfer";
        
        const withdrawTx = {
            id: "TX-" + Math.floor(10000 + Math.random() * 90000),
            date: formatCurrentDateTime(),
            type: "Capital Extraction",
            desc: `${claimType} details: ${walletLabel} | Net Payout: $${netUsd.toFixed(2)} USD`,
            status: "Success",
            coins: -amt
        };
        state.transactions.unshift(withdrawTx);
        
        // Save
        saveState();
        
        // Redraw interface
        updateBalanceUI(state.coins);
        renderTransactions();
        renderLeaderboard();
        
        // Reset fields
        elements.withdrawAmount.value = "";
        elements.walletRecipient.value = "";
        elements.liveConversionLbl.innerHTML = "$0.00 USD";
        
        // Alert
        showToast(`Success! Payout of $${netUsd.toFixed(2)} USD (after $${vatUsd.toFixed(2)} USD VAT) initiated!`, "success");
        showRewardPopup(amt, `Withdrawal to ${method.toUpperCase()} dispatched! Payout: $${netUsd.toFixed(2)} USD`);
    }

    // 16. SETTINGS SAVES
    function saveUserSettings() {
        const user = elements.settingsUsername.value.trim();
        const bkash = elements.settingsBkash.value.trim();
        
        if (!user) {
            showToast("Error: Username cannot be blank.", "error");
            return;
        }

        state.username = user;
        state.bkashNumber = bkash;
        
        saveState();
        
        // Update header user profiles
        document.querySelector(".profile-meta h4").innerText = user;
        showToast("Preferences saved securely to browser memory nodes.", "success");
        renderLeaderboard();
    }

    // 17. THEME MANAGER
    function applyTheme(themeName) {
        document.body.className = ""; // clear themes
        
        if (themeName === "classic") {
            document.body.classList.add("theme-classic");
            state.theme = "classic";
        } else if (themeName === "gold") {
            document.body.classList.add("theme-gold");
            state.theme = "gold";
        } else {
            state.theme = "cyberpunk";
        }
        saveState();
    }

    // 18. GENERAL UTILITIES
    function formatNumber(num) {
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }

    function formatCurrentDateTime() {
        const now = new Date();
        const pad = (n) => n.toString().padStart(2, "0");
        return `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}`;
    }

    function showToast(message, type = "success") {
        const toast = document.createElement("div");
        toast.className = `toast ${type}`;
        
        const icon = type === "success" 
            ? '<i class="fa-solid fa-circle-check"></i>' 
            : '<i class="fa-solid fa-triangle-exclamation"></i>';
            
        toast.innerHTML = `${icon} <span>${message}</span>`;
        elements.toastContainer.appendChild(toast);

        // Slide out animate and remove
        setTimeout(() => {
            toast.style.animation = "slideDown 0.3s forwards";
            setTimeout(() => {
                toast.remove();
            }, 300);
        }, 4000);
    }

    // Boot
    init();
});
