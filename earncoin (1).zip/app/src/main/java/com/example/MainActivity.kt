package com.example

import android.app.Dialog
import android.content.res.ColorStateList
import android.graphics.Color as AndroidColor
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.MyApplicationTheme
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.appopen.AppOpenAd
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : ComponentActivity() {
    
    var webViewInstance: WebView? = null
    private var loadingDialog: Dialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // 1. Initialize AdMob Mobile Ads SDK asynchronously
        try {
            MobileAds.initialize(this) {}
        } catch (e: Exception) {
            Log.e("MainActivity", "Failed to initialize MobileAds SDK: ${e.message}")
        }
        
        // Enable premium modern Edge-to-Edge immersion
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color(0xFF050208)) // Blends beautifully with EarnCoin Frosted Glass dark theme
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color(0xFF050208))
                            .statusBarsPadding()         // Prevents camera notch overlaps on the top navbar
                            .navigationBarsPadding()     // Prevents system gesture pill overlaps on the footer
                    ) {
                        EarnCoinWebView(this@MainActivity)
                    }
                }
            }
        }
    }

    // Displays a beautiful styled cyberpunk themed dialog while ads are downloading
    private fun showLoadingDialog() {
        runOnUiThread {
            dismissLoadingDialog()
            val dialog = Dialog(this)
            dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
            
            val layout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(60, 50, 60, 50)
                background = GradientDrawable().apply {
                    setColor(0xFF0D0614.toInt()) // Matte Cyber Dark Slate
                    setStroke(3, 0xFF39FF14.toInt()) // Neon Lime Green Cyber Glow
                    cornerRadius = 24f
                }
            }
            
            val pBar = ProgressBar(this).apply {
                indeterminateTintList = ColorStateList.valueOf(0xFF39FF14.toInt())
            }
            
            val textView = TextView(this).apply {
                text = "ESTABLISHING SECURE ADSTREAM...\nCONNECTING TO DECENTRALIZED NODE"
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(0xFFFFFFFF.toInt())
                typeface = Typeface.MONOSPACE
                setLineSpacing(5f, 1.2f)
                setPadding(0, 35, 0, 0)
            }
            
            layout.addView(pBar)
            layout.addView(textView)
            dialog.setContentView(layout)
            dialog.setCancelable(false)
            dialog.window?.setBackgroundDrawable(ColorDrawable(AndroidColor.TRANSPARENT))
            dialog.show()
            loadingDialog = dialog
        }
    }

    private fun dismissLoadingDialog() {
        runOnUiThread {
            loadingDialog?.dismiss()
            loadingDialog = null
        }
    }

    // Handles Ad Requests and matches the four user-supplied AdMob Ad Units
    fun showRealAd(adId: String, coins: Int, label: String) {
        showLoadingDialog()
        val adRequest = AdRequest.Builder().build()
        
        when (adId) {
            "reward" -> {
                // User Reward Ad ID: ca-app-pub-1989230444855050/1158574543
                RewardedAd.load(this, "ca-app-pub-1989230444855050/1158574543", adRequest, object : RewardedAdLoadCallback() {
                    override fun onAdLoaded(rewardedAd: RewardedAd) {
                        dismissLoadingDialog()
                        rewardedAd.show(this@MainActivity) { rewardItem ->
                            triggerWebViewReward(adId, coins, label)
                        }
                    }
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        dismissLoadingDialog()
                        runFallbackSimulation(adId, coins, label, "AdMob Reward Ad Failed: ${loadAdError.message}")
                    }
                })
            }
            "interstitial" -> {
                // User Interstitial Ad ID: ca-app-pub-1989230444855050/5490132410
                InterstitialAd.load(this, "ca-app-pub-1989230444855050/5490132410", adRequest, object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        dismissLoadingDialog()
                        interstitialAd.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                triggerWebViewReward(adId, coins, label)
                            }
                        }
                        interstitialAd.show(this@MainActivity)
                    }
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        dismissLoadingDialog()
                        runFallbackSimulation(adId, coins, label, "AdMob Interstitial Ad Failed: ${loadAdError.message}")
                    }
                })
            }
            "open" -> {
                // User App Open Ad ID: ca-app-pub-1989230444855050/7628909276
                AppOpenAd.load(this, "ca-app-pub-1989230444855050/7628909276", adRequest, object : AppOpenAd.AppOpenAdLoadCallback() {
                    override fun onAdLoaded(appOpenAd: AppOpenAd) {
                        dismissLoadingDialog()
                        appOpenAd.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                triggerWebViewReward(adId, coins, label)
                            }
                        }
                        appOpenAd.show(this@MainActivity)
                    }
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        dismissLoadingDialog()
                        runFallbackSimulation(adId, coins, label, "AdMob App Open Ad Failed: ${loadAdError.message}")
                    }
                })
            }
            "native" -> {
                // User Native Ad ID: ca-app-pub-1989230444855050/8603099072
                // We serve Native as an Interstitial for visual full-screen engagement and flawless HTML hybrid rendering
                InterstitialAd.load(this, "ca-app-pub-1989230444855050/8603099072", adRequest, object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        dismissLoadingDialog()
                        interstitialAd.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                triggerWebViewReward(adId, coins, label)
                            }
                        }
                        interstitialAd.show(this@MainActivity)
                    }
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        dismissLoadingDialog()
                        runFallbackSimulation(adId, coins, label, "AdMob Native Interstitial Failed: ${loadAdError.message}")
                    }
                })
            }
            "daily_checkin" -> {
                // Daily Checkin Ad, we load the highly lucrative user Interstitial Ad ID: ca-app-pub-1989230444855050/5490132410
                InterstitialAd.load(this, "ca-app-pub-1989230444855050/5490132410", adRequest, object : InterstitialAdLoadCallback() {
                    override fun onAdLoaded(interstitialAd: InterstitialAd) {
                        dismissLoadingDialog()
                        interstitialAd.fullScreenContentCallback = object : com.google.android.gms.ads.FullScreenContentCallback() {
                            override fun onAdDismissedFullScreenContent() {
                                triggerWebViewReward(adId, coins, label)
                            }
                        }
                        interstitialAd.show(this@MainActivity)
                    }
                    override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                        dismissLoadingDialog()
                        runFallbackSimulation(adId, coins, label, "AdMob Daily Check-In Interstitial Failed: ${loadAdError.message}")
                    }
                })
            }
            else -> {
                dismissLoadingDialog()
                runFallbackSimulation(adId, coins, label, "Unknown Ad Unit Type Specified")
            }
        }
    }

    private fun triggerWebViewReward(adId: String, coins: Int, label: String) {
        webViewInstance?.post {
            webViewInstance?.evaluateJavascript("javascript:if(typeof window.onAdCompleted === 'function'){ window.onAdCompleted('$adId', $coins, '$label'); }", null)
        }
        Toast.makeText(this, "Secure Coin Extraction Successful! +$coins Coins Mined.", Toast.LENGTH_SHORT).show()
    }

    private fun runFallbackSimulation(adId: String, coins: Int, label: String, errorDetails: String) {
        Log.e("MainActivity", "AdMob Error: $errorDetails")
        Toast.makeText(this, "Main network congestion detected. Initializing secondary secure simulation channel...", Toast.LENGTH_LONG).show()
        
        webViewInstance?.post {
            webViewInstance?.evaluateJavascript("javascript:if(typeof window.onAdFailedToLoad === 'function'){ window.onAdFailedToLoad('$adId', $coins, '$label'); }", null)
        }
    }

    // Bridge Class mapped inside JavaScript
    class AndroidBridge(private val activity: MainActivity) {
        @JavascriptInterface
        fun showAd(adId: String, coins: Int, label: String) {
            activity.runOnUiThread {
                activity.showRealAd(adId, coins, label)
            }
        }
    }
}

@Composable
fun EarnCoinWebView(activity: MainActivity) {
    AndroidView(
        factory = { context ->
            WebView(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                
                // Set custom WebView Client
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, url: String?): Boolean {
                        // Keep navigation inside WebView
                        return false
                    }
                }
                
                // Configure standard modern web settings for interactive webapps
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    allowFileAccess = true
                    allowContentAccess = true
                    mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                }
                
                // Register the Native JavaScript Bridge
                addJavascriptInterface(MainActivity.AndroidBridge(activity), "AndroidBridge")
                
                // Assign WebView Instance back to activity for callbacks
                activity.webViewInstance = this
                
                // Load local compiled assets
                loadUrl("file:///android_asset/index.html")
                
                // Set solid dark background to avoid white flashing during boot
                setBackgroundColor(0xFF050208.toInt())
            }
        },
        modifier = Modifier.fillMaxSize()
    )
}
